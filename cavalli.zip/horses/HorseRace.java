/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horses;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author sasha
 */
public class HorseRace extends javax.swing.JFrame {
    public static void main(String args[]) {
        new HorseRace();
    }

    public HorseRace() {
        /* Costruttore */
        javax.swing.JFrame cornice_corsa = new CorniceCorsa();
        cornice_corsa.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        cornice_corsa.setVisible(true);
    }
}