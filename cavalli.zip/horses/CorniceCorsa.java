/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horses;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/**
 *
 * @author sasha
 */
public class CorniceCorsa extends javax.swing.JFrame {
    private JPanel pannello_corsa;
    private JPanel pannello_cavalli;
    private PistaDaCorsa pista = new PistaDaCorsa();
    private JButton bottone_inizio_corsa = new JButton("Via!");
    private JButton bottone_reset_corsa = new JButton("Reset");
    public int finestra_altezza = 768;
    public int finestra_larghezza = 1024;

    public CorniceCorsa(){
        creaInterfaccia();
        agganciaListenerVia();
        setSize(finestra_larghezza,finestra_altezza);
    }

    public void creaInterfaccia (){
        pannello_corsa = new JPanel();
        pannello_cavalli = new JPanel();
        pista = new PistaDaCorsa();
        /* piazzamenro layout */
        disponiPannelli(pannello_cavalli, pannello_corsa);
    }
    
    public void agganciaListenerVia(){
        class InizioGara implements ActionListener{
            public void actionPerformed(ActionEvent _evento){
            bottone_inizio_corsa.setEnabled(true);
            pista.start();
            }
        }
        ActionListener evento = new InizioGara();
        bottone_inizio_corsa.addActionListener(evento);
    }
     /* crea lòistener per il bnottone Start */
     /* crea listener per il bottore Reset */

    public void disponiPannelli(JPanel _pannello_cavalli, JPanel _pannello_corsa){
        /* definire meglio il piazzamento degli elementi */
        _pannello_cavalli.add(bottone_inizio_corsa);
        _pannello_cavalli.add(bottone_reset_corsa);
        _pannello_corsa.add(_pannello_cavalli);
        _pannello_corsa.add(pista);
        add(_pannello_corsa);
    }
}
